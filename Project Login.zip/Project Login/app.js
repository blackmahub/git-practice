 // create the module and name it scotchApp
   var app = angular.module('MyWebApp', []);
	app.controller('myLoginCtrl', function($scope,$http) {
		
		$scope.SignIn = function(){
			$scope.inputEmail= "";
			$scope.inputPassword="";
			/*
			var url="";
			$http.get(url).success( function(response) {
			if(response ==true){
				$scope.inputEmail= "";
				$scope.inputPassword="";
			}
			else{

			}
						
			});	
			*/
		}
    
	});